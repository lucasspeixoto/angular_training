import { Injectable } from '@angular/core';

@Injectable({ //Esse decorator vai permitir essa classe ser injetada (via construtor) em outra para uso.
  providedIn: 'root'
})
export class CursosService {

  constructor() { }

  getCursos() {
    return ['Angular', 'React', 'Electron', 'Python', 'Django', 'JavaScript', 'PHP']
  }
}
