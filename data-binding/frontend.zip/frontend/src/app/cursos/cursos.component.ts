import { Component, OnInit } from '@angular/core';

import { CursosService } from './cursos.service';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {

  nomePortal!: string;
  cursos!: string[]
  product: boolean = false

  constructor(private cursoService: CursosService) {
    this.nomePortal = 'https://loiane.training'

   }

  ngOnInit(): void {
    this.cursos = this.cursoService.getCursos()

    setTimeout(() => {
      this.product = true
    }, 4000)

  }


}
