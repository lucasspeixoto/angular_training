import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cursos-detalhe',
  templateUrl: './cursos-detalhe.component.html',
  styleUrls: ['./cursos-detalhe.component.css']
})
export class CursosDetalheComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
