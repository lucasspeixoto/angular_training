import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CursosComponent } from './cursos.component';
import { CursosDetalheComponent } from './cursos-detalhe/cursos-detalhe.component';

@NgModule({
  declarations: [
    CursosComponent,
    CursosDetalheComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    CursosComponent /*Colocando o componente aqui, ele vai ficar visível
para outros modulos, não apenas no cursos.module, ou seja, podemos chamar
no app.component.html (Antes precisamos chamar o o módulo no app module) */
  ]
})
export class CursosModule { }
