import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser'; //Prepara o app para rodar nos browsers

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CursosModule } from './cursos/cursos.module';
import { CursosService } from './cursos/cursos.service';
import { MeuPrimeiroComponent } from './meu-primeiro/meu-primeiro.component';
import { MeuSegundoComponent } from './meu-segundo/meu-segundo.component';
@NgModule({
  declarations: [ /*Aqui vamos listar componentes, diretivas e pipes do módulo*/
    AppComponent,
    MeuPrimeiroComponent,
    MeuSegundoComponent,
  ],
  imports: [ /* Outros módulos que serão importados */
    BrowserModule,
    AppRoutingModule,
    CursosModule //Para utilizar componentes do modulo Cursos
  ],
  providers: [CursosService], /* Aqui vamos colocar todos os servidos */
  bootstrap: [AppComponent] /* Componente que deve ser instanciado quando iniciar a aplicação */
})
export class AppModule { }
