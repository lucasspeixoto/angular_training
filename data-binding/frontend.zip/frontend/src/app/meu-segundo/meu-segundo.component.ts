import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meu-segundo',
  templateUrl: './meu-segundo.component.html',
  styleUrls: ['./meu-segundo.component.css']
})
export class MeuSegundoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
