import { Component } from "@angular/core";


@Component({ //Metadados
  selector: 'meu-primeiro-component',
  template: `
    <ul>
      <li>Lucas</li>
      <li>Liana</li>
      <li>César</li>
      <li>Cecícila</li>
    </ul>
  `
}

)
export class MeuPrimeiroComponent {} /*
Sem o export o Componente não é visto e em app.component.html não vai ser encontrado
Alem do export, é necessário declarar no módulo app.module */
